#include "fx_impares.h"

int main(){

    fixtureImpares f2(5);

    f2.mostrarEquipos(5);

    return 0;
}