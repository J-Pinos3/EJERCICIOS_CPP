#include"fx_pares.h"

int main(){

    fixturePares f1(6);

    f1.mostrarEquipos(6);

    return 0;
}